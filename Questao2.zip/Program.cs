﻿using System;
using System.Linq;

namespace Questao2
{
    class Program
    {
        static void MediaMaiores(int[] elementos)
        {
            Console.WriteLine("A média dos elementos da lista é igual a: " + elementos.Average());
            Console.WriteLine("Os elementos maiores que a média são: ");
            foreach (int n in elementos)
            {
                if (n > elementos.Average())
                {
                    Console.WriteLine(n);
                }
            }
            
        }

        static void ListaInvertida(int[] itens)
        {
            Array.Reverse(itens);
            Console.WriteLine("Invertendo a ordem dos elementos da lista, temos: ");
            foreach (int i in itens)
            {
                Console.WriteLine(i);
            }
        }
        static void Main(string[] args)
        {
            int[] lista = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9};
            MediaMaiores(lista);
            ListaInvertida(lista);
            Console.Read();

        }
    }
}
